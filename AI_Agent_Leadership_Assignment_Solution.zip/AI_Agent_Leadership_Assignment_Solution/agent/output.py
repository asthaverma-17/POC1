import json
import pandas as pd
from agent.config import TARGETS
from pathlib import Path
from agent.state import AgentState

OUTPUT_DIR = Path("outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


def build_contract(state: AgentState):

    kpis = state["kpis"]
    comments = state["kpi_comments"]
    print("Building contract with KPIs:", kpis)
    print("Comments for KPIs:", comments)
    kpi_summary = []

    for name, value in kpis.items():

        target = TARGETS.get(name, 0)
        delta = round(value - target, 2)

        if value >= target:
            status = "GREEN"
        elif value >= target * 0.9:
            status = "AMBER"
        else:
            status = "RED"

        kpi_summary.append({
            "KPI": name,
            "Current": round(value, 2),
            "Target": target,
            "Delta": delta,
            "Status": status,
            "Comment": comments.get(name, "")
        })

    result = {
        "header": {
            "period": "Current Period",
            "warehouses": "All",
        },
        "kpi_summary": kpi_summary,
        "insights_actions": [
            {
                "Area": "Validation",
                "Insight/Risk/Action": err
            }
            for err in state.get("validated", [])
        ]
    }

    return result

def save_json(contract):

    with open(OUTPUT_DIR / "one_pager.json", "w") as f:
        json.dump(contract, f, indent=4)

def generate_html(contract):

    header = contract["header"]
    kpis = contract["kpi_summary"]
    insights = contract["insights_actions"]

    html = f"""
    <html>
    <head>
    <style>
        body {{ font-family: Arial; margin: 40px; }}
        h1 {{ text-align: center; }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }}
        th {{ background-color: #f4f4f4; }}

        .GREEN {{ background-color: #d4edda; }}
        .AMBER {{ background-color: #fff3cd; }}
        .RED {{ background-color: #f8d7da; }}
    </style>
    </head>
    <body>

    <h1>Leadership KPI Summary</h1>

    <p><b>Period:</b> {header['period']}</p>
    <p><b>Warehouses:</b> {header['warehouses']}</p>

    <h2>KPI Summary</h2>
    <table>
        <tr>
            <th>KPI</th>
            <th>Current</th>
            <th>Target</th>
            <th>Delta</th>
            <th>Status</th>
            <th>Comment</th>
        </tr>
    """

    for row in kpis:
        html += f"""
        <tr class="{row['Status']}">
            <td>{row['KPI']}</td>
            <td>{row['Current']}</td>
            <td>{row['Target']}</td>
            <td>{row['Delta']}</td>
            <td>{row['Status']}</td>
            <td>{row['Comment']}</td>
        </tr>
        """

    html += """
    </table>

    <h2>Insights & Actions</h2>
    <table>
        <tr>
            <th>Area</th>
            <th>Insight / Risk / Action</th>
        </tr>
    """

    for row in insights:
        html += f"""
        <tr>
            <td>{row['Area']}</td>
            <td>{row['Insight/Risk/Action']}</td>
        </tr>
        """

    html += """
    </table>
    </body>
    </html>
    """

    with open(OUTPUT_DIR / "one_pager.html", "w") as f:
        f.write(html)

def generate_excel(contract):

    kpi_df = pd.DataFrame(contract["kpi_summary"])
    insights_df = pd.DataFrame(contract["insights_actions"])

    with pd.ExcelWriter(OUTPUT_DIR / "one_pager.xlsx") as writer:
        kpi_df.to_excel(writer, sheet_name="KPI_Summary", index=False)
        insights_df.to_excel(writer, sheet_name="Insights_Actions", index=False)

def output_node(state: AgentState):

    contract = build_contract(state)

    save_json(contract)
    generate_html(contract)
    generate_excel(contract)

    print("Outputs generated successfully.")

    return state