DATA_DIR = "data"

TARGETS = {
    "Fill Rate %": 95.0,
    "OTIF %": 92.0,
    "Days of Supply": 25,
    "Lines Picked per Labor-Hour": 6.0,
    "Error Rate %": 0.8,
}