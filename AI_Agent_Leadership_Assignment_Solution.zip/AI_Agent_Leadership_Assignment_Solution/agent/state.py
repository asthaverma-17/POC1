# agent/state.py

from typing import TypedDict, Dict, Any

class AgentState(TypedDict):
    start_date: str
    end_date: str
    warehouses: list
    raw_data: Dict[str, Any]
    validated: bool
    kpis: Dict[str, float]
    kpi_comments: Dict[str, str]
    quality_score: float
    summary: str
    output_path: str
    error: str