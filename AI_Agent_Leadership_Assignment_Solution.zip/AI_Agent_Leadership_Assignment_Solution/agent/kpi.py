from agent.state import AgentState

def compute_kpis_node(state:AgentState):

    data = state["raw_data"]

    outbound = data["outbound_parts"]
    inbound = data["inbound_parts"]
    inventory = data["inventory_snapshot"]
    warehouse = data["warehouse_productivity"]
    employee = data["employee_productivity"]

    kpis = {}

    # Fill Rate
    kpis["Fill Rate %"] = (
        outbound["qty_shipped"].sum() /
        outbound["qty_ordered"].sum()
    ) * 100

    # OTIF
    kpis["OTIF %"] = (
        outbound["otif_flag"].sum() /
        len(outbound)
    ) * 100

    # Days of Supply
    kpis["Days of Supply"] = (
        inventory["on_hand_qty"].sum() /
        outbound["qty_shipped"].mean()
    )

    # Lines per Labor Hour
    kpis["Lines Picked per Labor-Hour"] = (
        warehouse["lines_picked"].sum() /
        warehouse["labor_hours"].sum()
    )

    # Error Rate
    kpis["Error Rate %"] = (
        employee["errors"].sum() /
        employee["tasks_completed"].sum()
    ) * 100

    state["kpis"] = kpis
    return state