from agent.nodes.validation_node import validation_node
from agent.state import AgentState
from pathlib import Path
from agent.config import DATA_DIR

def load_all(state: AgentState):
    try:
        import pandas as pd
        # Initialize raw_data in state
        state["raw_data"] = {}
        
        files = [
        "inbound_parts.csv",
        "outbound_parts.csv",
        "inventory_snapshot.csv",
        "warehouse_productivity.csv",
        "employee_productivity.csv"
        ]

        for file in files:
            path = Path(DATA_DIR) / file
            state["raw_data"][file.replace(".csv","")] = pd.read_csv(path)
        print("Data loaded successfully.",state)
        required_cols = {
            "Inbound": ["Avg lead time", "% on-time receipts", "% discrepancy", "Risks/Actions"],
            "Outbound": ["Fill rate", "OTIF", "Backorder rate", "Top SKUs by backorder"],
            "Inventory": ["DOS", "% stock-outs", "Aged value", "Risks/Actions"],
            "Warehouse Productivity": ["Lines/hour", "Orders/day", "SLA adherence"],
            "Employee Productivity": ["Picks/person/hour", "Error rate", "Overtime %"]
        }

        for data_name in state["raw_data"].items():
            state = validation_node(state, required_cols.get(data_name, []), data_name)
        
        return state
    except Exception as e:
        state["error"] = str(e)
        return state