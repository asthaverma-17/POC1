import time
from langchain_ollama import OllamaLLM
from agent.config import TARGETS
from agent.state import AgentState

# Initialize local Ollama model
llm = OllamaLLM(model="llama2:latest")


def generate_comment(prompt):

    for attempt in range(3):
        try:
            response = llm.invoke(prompt)
            return response.strip()

        except Exception as e:
            time.sleep(1)

    return "Performance deviation observed. Requires review."


def comment_node(state:AgentState):

    comments = {}
    kpis = state["kpis"]
    # quality = state["quality_score"]
    # print("Generating comments for KPIs with quality score:", quality)
    print("KPIs:", kpis)
    for name, value in kpis.items():
        target = TARGETS.get(name, 0)
        delta = round(value - target, 2)

        prompt = f"""
You are an executive supply chain analyst.

KPI: {name}
Current: {value}
Target: {target}
Delta: {delta}

Write a concise executive comment (max 2-8 words).
If below target → explain risk.
If above target → explain positive impact.
"""

        comments[name] = generate_comment(prompt)

    state["kpi_comments"] = comments
    return state