from langchain_ollama import OllamaLLM
from agent.state import AgentState

llm = OllamaLLM(model="llama2:latest")

def narrative_node(state:AgentState):

    prompt = f"""
Generate a short executive summary from these KPIs:

{state['kpis']}

"""

    summary = llm.invoke(prompt)

    state["summary"] = summary
    return state