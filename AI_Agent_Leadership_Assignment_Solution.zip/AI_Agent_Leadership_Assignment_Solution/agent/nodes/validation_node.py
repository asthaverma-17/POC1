from agent.state import AgentState

def validation_node(state: AgentState, required_cols: list, data_name: str):
    try:
        data = state["raw_data"][data_name]

        for col in required_cols:
            if col not in data.columns:
                raise ValueError(f"Missing column {col}")
        
        state["validated"] = True
        return state
    
    except Exception as e:
        state["error"] = f"Validation Failed: {e}"
        state["validated"] = False
        return state