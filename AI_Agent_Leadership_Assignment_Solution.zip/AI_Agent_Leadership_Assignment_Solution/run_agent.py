from langgraph.graph import StateGraph
from agent.ingest import load_all
from agent.kpi import compute_kpis_node
from agent.nodes.comment_node import comment_node
from agent.nodes.narrative_node import narrative_node
from agent.output import output_node
from agent.state import AgentState

builder = StateGraph(dict)

builder.add_node("ingest", load_all)
print("Ingest node added.")
builder.add_node("kpi", compute_kpis_node)
builder.add_node("comments", comment_node)
builder.add_node("narrative", narrative_node)
builder.add_node("output", output_node)

builder.set_entry_point("ingest")

builder.add_edge("ingest","kpi")
builder.add_edge("kpi","comments")
builder.add_edge("comments","narrative")
builder.add_edge("narrative","output")

graph = builder.compile()
print("Graph compiled successfully. Starting execution...")
if __name__ == "__main__":
    graph.invoke(AgentState)
    print("Agent execution completed.")