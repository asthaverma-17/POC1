
import pandas as pd
from datetime import datetime

# Example KPI functions (add more as needed)

def inbound_avg_lead_days(inbound: pd.DataFrame, start: datetime, end: datetime):
    df = inbound[(inbound['received_date']>=start)&(inbound['received_date']<=end)]
    return float((df['received_date'] - df['expected_date']).dt.days.mean())


def inbound_on_time_pct(inbound: pd.DataFrame, start, end):
    df = inbound[(inbound['received_date']>=start)&(inbound['received_date']<=end)]
    return float((df['received_date'] <= df['expected_date']).mean())


def outbound_fill_rate(outbound: pd.DataFrame, start, end):
    df = outbound[(outbound['shipped_date']>=start)&(outbound['shipped_date']<=end)]
    ordered = df['qty_ordered'].sum()
    return float(df['qty_shipped'].sum()/ordered) if ordered else 0.0


def outbound_otif_pct(outbound: pd.DataFrame, start, end):
    df = outbound[(outbound['shipped_date']>=start)&(outbound['shipped_date']<=end)]
    return float(df['otif_flag'].mean()) if len(df)>0 else 0.0
