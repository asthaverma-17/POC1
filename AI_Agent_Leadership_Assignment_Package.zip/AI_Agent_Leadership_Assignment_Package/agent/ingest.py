
import pandas as pd
from pathlib import Path

DATA_DIR = '<<path>>'

def load_all():
    pass
